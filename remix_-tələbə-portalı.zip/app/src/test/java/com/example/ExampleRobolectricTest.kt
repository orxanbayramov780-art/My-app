package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.utils.Localization
import com.example.utils.SecurityUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun verifyAppNameResource() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Tələbə Portalı", appName)
    }

    @Test
    fun verifyPasswordHashingAxiom() {
        val password = "tural_student_secure99"
        val hashValue = SecurityUtils.hashPassword(password)
        
        // Assert hash is stable and verified
        assertTrue(SecurityUtils.verifyPassword(password, hashValue))
    }

    @Test
    fun verifyLocalizationDictionary() {
        val appTitleAZ = Localization.getString("AZ", "app_title")
        val appTitleTR = Localization.getString("TR", "app_title")
        val appTitleRU = Localization.getString("RU", "app_title")
        val appTitleEN = Localization.getString("EN", "app_title")

        assertEquals("Tələbə Portalı", appTitleAZ)
        assertEquals("Öğrenci Portalı", appTitleTR)
        assertEquals("Студенческий Портал", appTitleRU)
        assertEquals("Student Portal", appTitleEN)
    }
}
