package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val tamAd: String,
    val email: String,
    val telefonNomresi: String,
    val sifreHash: String,
    val universitet: String,
    val fakulte: String,
    val ixtisas: String,
    val secilmisDil: String = "AZ",
    val secilmisTema: String = "light",
    val isAnonymous: Boolean = false,
    val yaradilmaTarixi: Long = System.currentTimeMillis()
)
