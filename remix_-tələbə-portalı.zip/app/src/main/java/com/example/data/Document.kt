package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "documents")
data class Document(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val basliq: String,
    val aciqlama: String,
    val faylYolu: String,
    val faylOlcusu: Double, // File size in MB
    val yukleyenUserId: Int,
    val universitet: String,
    val ixtisas: String,
    val fənn: String,
    var downloadSayi: Int = 0,
    var upvoteSayi: Int = 0,
    var downvoteSayi: Int = 0,
    val isApproved: Boolean = true, // Moderator approval, defaults to true
    val yaradilmaTarixi: Long = System.currentTimeMillis()
)
