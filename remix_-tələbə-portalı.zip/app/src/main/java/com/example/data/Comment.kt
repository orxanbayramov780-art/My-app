package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "comments")
data class Comment(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val senedId: Int,
    val userId: Int,
    val metn: String,
    val yaradilmaTarixi: Long = System.currentTimeMillis()
)
