package com.example.data

import android.content.Context
import android.util.Log
import com.example.api.*
import com.example.utils.SecurityUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class StudentRepository(private val db: AppDatabase) {
    val userDao = db.userDao()
    val documentDao = db.documentDao()
    val commentDao = db.commentDao()

    init {
        // Run database seeding on in-app initialization using a background thread
        CoroutineScope(Dispatchers.IO).launch {
            seedDatabaseIfEmpty()
            // After seeding/checking local database, trigger initial Supabase synchronization
            syncAllDocuments()
        }
    }

    // Sync all documents from Supabase to local Room
    suspend fun syncAllDocuments() = withContext(Dispatchers.IO) {
        try {
            val remote = SupabaseClient.service.getAllDocuments()
            if (remote.isNotEmpty()) {
                remote.forEach {
                    documentDao.insertDocument(it.toRoomDocument())
                }
                Log.d("StudentRepository", "Successfully synced ${remote.size} documents from Supabase")
            }
        } catch (e: Exception) {
            Log.e("StudentRepository", "syncAllDocuments cloud call failed", e)
        }
    }

    // Sync comments for a document from Supabase to local Room
    suspend fun syncComments(docId: Int) = withContext(Dispatchers.IO) {
        try {
            val remote = SupabaseClient.service.getCommentsForDocument("senedId=eq.$docId")
            if (remote.isNotEmpty()) {
                remote.forEach {
                    commentDao.insertComment(it.toRoomComment())
                }
                Log.d("StudentRepository", "Successfully synced ${remote.size} comments for document $docId")
            }
        } catch (e: Exception) {
            Log.e("StudentRepository", "syncComments cloud call failed", e)
        }
    }

    fun getAllDocuments(): Flow<List<Document>> = documentDao.getAllApprovedDocuments()

    fun getDocumentsByUniversity(uni: String): Flow<List<Document>> {
        return if (uni == "Bütün Universitetlər" || uni == "All Universities" || uni == "Tüm Üniversiteler" || uni == "Все Университеты") {
            documentDao.getAllApprovedDocuments()
        } else {
            documentDao.getDocumentsByUniversity(uni)
        }
    }

    fun getCommentsForDocument(docId: Int): Flow<List<Comment>> = commentDao.getCommentsForDocument(docId)

    suspend fun getUserById(userId: Int): User? = withContext(Dispatchers.IO) {
        try {
            val remote = SupabaseClient.service.getUserById("id=eq.$userId")
            if (remote.isNotEmpty()) {
                val user = remote.first().toRoomUser()
                userDao.insertUser(user)
                return@withContext user
            }
        } catch (e: Exception) {
            Log.e("StudentRepository", "getUserById Supabase failed", e)
        }
        userDao.getUserById(userId)
    }

    suspend fun getUserByEmail(email: String): User? = withContext(Dispatchers.IO) {
        try {
            val remote = SupabaseClient.service.getUserByEmail("email=eq.$email")
            if (remote.isNotEmpty()) {
                val user = remote.first().toRoomUser()
                userDao.insertUser(user)
                return@withContext user
            }
        } catch (e: Exception) {
            Log.e("StudentRepository", "getUserByEmail Supabase failed", e)
        }
        userDao.getUserByEmail(email)
    }

    suspend fun getUserByPhone(phone: String): User? = withContext(Dispatchers.IO) {
        try {
            val remote = SupabaseClient.service.getUserByPhone("telefonNomresi=eq.$phone")
            if (remote.isNotEmpty()) {
                val user = remote.first().toRoomUser()
                userDao.insertUser(user)
                return@withContext user
            }
        } catch (e: Exception) {
            Log.e("StudentRepository", "getUserByPhone Supabase failed", e)
        }
        userDao.getUserByPhone(phone)
    }

    suspend fun insertUser(user: User): Long = withContext(Dispatchers.IO) {
        try {
            val req = SupabaseUserRequest(
                tamAd = user.tamAd,
                email = user.email,
                telefonNomresi = user.telefonNomresi,
                sifreHash = user.sifreHash,
                universitet = user.universitet,
                fakulte = user.fakulte,
                ixtisas = user.ixtisas,
                secilmisDil = user.secilmisDil,
                secilmisTema = user.secilmisTema,
                isAnonymous = user.isAnonymous,
                yaradilmaTarixi = user.yaradilmaTarixi
            )
            val remote = SupabaseClient.service.insertUser(req)
            if (remote.isNotEmpty()) {
                val inserted = remote.first().toRoomUser()
                return@withContext userDao.insertUser(inserted)
            }
        } catch (e: Exception) {
            Log.e("StudentRepository", "insertUser Supabase failed", e)
        }
        userDao.insertUser(user)
    }

    suspend fun updateUser(user: User) = withContext(Dispatchers.IO) {
        try {
            val updates = mapOf(
                "secilmisDil" to user.secilmisDil,
                "secilmisTema" to user.secilmisTema,
                "isAnonymous" to user.isAnonymous.toString()
            )
            SupabaseClient.service.updateUser("id=eq.${user.id}", updates)
        } catch (e: Exception) {
            Log.e("StudentRepository", "updateUser Supabase failed", e)
        }
        userDao.updateUser(user)
    }

    suspend fun insertDocument(document: Document): Long = withContext(Dispatchers.IO) {
        try {
            val req = SupabaseDocumentRequest(
                basliq = document.basliq,
                aciqlama = document.aciqlama,
                faylYolu = document.faylYolu,
                faylOlcusu = document.faylOlcusu,
                yukleyenUserId = document.yukleyenUserId,
                universitet = document.universitet,
                ixtisas = document.ixtisas,
                fənn = document.fənn,
                downloadSayi = document.downloadSayi,
                upvoteSayi = document.upvoteSayi,
                downvoteSayi = document.downvoteSayi,
                isApproved = document.isApproved,
                yaradilmaTarixi = document.yaradilmaTarixi
            )
            val remote = SupabaseClient.service.insertDocument(req)
            if (remote.isNotEmpty()) {
                val inserted = remote.first().toRoomDocument()
                return@withContext documentDao.insertDocument(inserted)
            }
        } catch (e: Exception) {
            Log.e("StudentRepository", "insertDocument Supabase failed", e)
        }
        documentDao.insertDocument(document)
    }

    suspend fun updateDocument(document: Document) = withContext(Dispatchers.IO) {
        try {
            val updates = mapOf(
                "downloadSayi" to document.downloadSayi,
                "upvoteSayi" to document.upvoteSayi,
                "downvoteSayi" to document.downvoteSayi
            )
            SupabaseClient.service.patchDocument("id=eq.${document.id}", updates)
        } catch (e: Exception) {
            Log.e("StudentRepository", "updateDocument Supabase failed", e)
        }
        documentDao.updateDocument(document)
    }

    suspend fun insertComment(comment: Comment): Long = withContext(Dispatchers.IO) {
        try {
            val req = SupabaseCommentRequest(
                senedId = comment.senedId,
                userId = comment.userId,
                metn = comment.metn,
                yaradilmaTarixi = comment.yaradilmaTarixi
            )
            val remote = SupabaseClient.service.insertComment(req)
            if (remote.isNotEmpty()) {
                val inserted = remote.first().toRoomComment()
                return@withContext commentDao.insertComment(inserted)
            }
        } catch (e: Exception) {
            Log.e("StudentRepository", "insertComment Supabase failed", e)
        }
        commentDao.insertComment(comment)
    }

    suspend fun getDocumentById(id: Int): Document? = withContext(Dispatchers.IO) {
        documentDao.getDocumentById(id)
    }

    // Increments downloads
    suspend fun incrementDownload(docId: Int) = withContext(Dispatchers.IO) {
        val doc = documentDao.getDocumentById(docId)
        if (doc != null) {
            val updatedVal = doc.downloadSayi + 1
            try {
                SupabaseClient.service.patchDocument("id=eq.$docId", mapOf("downloadSayi" to updatedVal))
            } catch (e: Exception) {
                Log.e("StudentRepository", "incrementDownload Supabase failed", e)
            }
            documentDao.updateDocument(doc.copy(downloadSayi = updatedVal))
        }
    }

    // Upvotes a document
    suspend fun upvoteDocument(docId: Int) = withContext(Dispatchers.IO) {
        val doc = documentDao.getDocumentById(docId)
        if (doc != null) {
            val updatedVal = doc.upvoteSayi + 1
            try {
                SupabaseClient.service.patchDocument("id=eq.$docId", mapOf("upvoteSayi" to updatedVal))
            } catch (e: Exception) {
                Log.e("StudentRepository", "upvoteDocument Supabase failed", e)
            }
            documentDao.updateDocument(doc.copy(upvoteSayi = updatedVal))
        }
    }

    // Downvotes a document
    suspend fun downvoteDocument(docId: Int) = withContext(Dispatchers.IO) {
        val doc = documentDao.getDocumentById(docId)
        if (doc != null) {
            val updatedVal = doc.downvoteSayi + 1
            try {
                SupabaseClient.service.patchDocument("id=eq.$docId", mapOf("downvoteSayi" to updatedVal))
            } catch (e: Exception) {
                Log.e("StudentRepository", "downvoteDocument Supabase failed", e)
            }
            documentDao.updateDocument(doc.copy(downvoteSayi = updatedVal))
        }
    }

    // Database seeding mechanism
    private suspend fun seedDatabaseIfEmpty() {
        val existingUser = userDao.getUserById(1)
        if (existingUser == null) {
            // 1. Seed demo students and creators
            val pasha = User(
                id = 1,
                tamAd = "Paşayev Tural",
                email = "tural@bdu.edu.az",
                telefonNomresi = "+994501234567",
                sifreHash = SecurityUtils.hashPassword("tural123"),
                universitet = "BDU",
                fakulte = "Tətbiqi Riyaziyyat",
                ixtisas = "Kompüter Elmləri",
                secilmisDil = "AZ",
                secilmisTema = "light",
                isAnonymous = false
            )
            val leyla = User(
                id = 2,
                tamAd = "Əliyeva Leyla",
                email = "leyla@unec.edu.az",
                telefonNomresi = "+994559876543",
                sifreHash = SecurityUtils.hashPassword("leyla123"),
                universitet = "UNEC",
                fakulte = "Maliyyə",
                ixtisas = "Maliyyə",
                secilmisDil = "AZ",
                secilmisTema = "light",
                isAnonymous = true // Anonymous user test!
            )
            val farid = User(
                id = 3,
                tamAd = "Məmmədov Fərid",
                email = "farid@azmiu.edu.az",
                telefonNomresi = "+994705554433",
                sifreHash = SecurityUtils.hashPassword("farid123"),
                universitet = "AZMİU",
                fakulte = "İnşaat",
                ixtisas = "İnşaat Mühəndisliyi",
                secilmisDil = "EN",
                secilmisTema = "dark",
                isAnonymous = false
            )

            userDao.insertUser(pasha)
            userDao.insertUser(leyla)
            userDao.insertUser(farid)

            // 2. Seed university documents
            val doc1 = Document(
                id = 1,
                basliq = "Analitik Həndəsə Mühazirələri",
                aciqlama = "Bakı Dövlət Universiteti Riyaziyyat fakültəsi tələbələri üçün I və II semestr əhatəli tam analitik həndəsə mühazirə qeydləri.",
                faylYolu = "bdu_analitik_hendese_2026.pdf",
                faylOlcusu = 4.2,
                yukleyenUserId = 1,
                universitet = "BDU",
                ixtisas = "Riyaziyyat",
                fənn = "Analitik Həndəsə",
                downloadSayi = 142,
                upvoteSayi = 54,
                downvoteSayi = 2,
                isApproved = true
            )

            val doc2 = Document(
                id = 2,
                basliq = "Mikroiqtisadiyyat İmtahan Testləri",
                aciqlama = "UNEC Maliyyə və İqtisadiyyat ixtisası üzrə final imtahanından öncə paylaşılan rəsmi hazırlıq sualları, cavabları ilə birgə.",
                faylYolu = "unec_macro_micro_exam_prep.pdf",
                faylOlcusu = 1.8,
                yukleyenUserId = 2, // Leyla is anonymous => should display as Anonymous Student!
                universitet = "UNEC",
                ixtisas = "Maliyyə və İqtisadiyyat",
                fənn = "Mikroiqtisadiyyat",
                downloadSayi = 310,
                upvoteSayi = 98,
                downvoteSayi = 1,
                isApproved = true
            )

            val doc3 = Document(
                id = 3,
                basliq = "Tikinti Mexanikası və Konstruktiv Hesablamalar",
                aciqlama = "AZMİU İnşaat mühəndisliyi tələbələri üçün laboratoriya işləri və statik təyin olunan sistemlərin hesablanması bələdçisi.",
                faylYolu = "azmiu_construction_mech_lab.docx",
                faylOlcusu = 12.5,
                yukleyenUserId = 3,
                universitet = "AZMİU",
                ixtisas = "İnşaat Mühəndisliyi",
                fənn = "Tikinti Mexanikası",
                downloadSayi = 45,
                upvoteSayi = 18,
                downvoteSayi = 0,
                isApproved = true
            )

            documentDao.insertDocument(doc1)
            documentDao.insertDocument(doc2)
            documentDao.insertDocument(doc3)

            // 3. Seed comments
            val comm1 = Comment(
                id = 1,
                senedId = 1,
                userId = 2, // Leyla is anonymous -> should say "Anonim Tələbə"
                metn = "Çox sistemli yazılıb hazırlanıb. Müəllimin slaydlarından qat-qat anlaşıqlıdır, hamınıza tövsiyə edirəm!",
                yaradilmaTarixi = System.currentTimeMillis() - 86400000 * 3
            )
            val comm2 = Comment(
                id = 2,
                senedId = 1,
                userId = 3,
                metn = "Zəhmət olmasa 2-ci hissəsini də yükləyə bilərsiniz? Çox kömək oldu.",
                yaradilmaTarixi = System.currentTimeMillis() - 86400000 * 2
            )
            val comm3 = Comment(
                id = 3,
                senedId = 2,
                userId = 1,
                metn = "Uşaqlar, imtahandakı 10 sualdan 8-i tam olaraq burdakı suallarla üst-üstə düşdü! Möhtəşəmdir!!!",
                yaradilmaTarixi = System.currentTimeMillis() - 3600000 * 4
            )

            commentDao.insertComment(comm1)
            commentDao.insertComment(comm2)
            commentDao.insertComment(comm3)
        }
    }
}
