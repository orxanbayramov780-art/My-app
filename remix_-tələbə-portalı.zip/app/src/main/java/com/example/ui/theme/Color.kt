package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean Minimalism Palette
val MinimalBlue = Color(0xFF005FB8)
val MinimalBlueDark = Color(0xFF004A8F)
val MinimalBackgroundLight = Color(0xFFF7F9FC)
val MinimalTextDark = Color(0xFF1A1C1E)
val MinimalTextSecondary = Color(0xFF40484E)
val MinimalTextMuted = Color(0xFF70777C)
val MinimalBorder = Color(0xFFDDE2EA)
val MinimalLightGray = Color(0xFFF0F2F5)

// Secondary/Accent Colors
val AccentRedLight = Color(0xFFFDF2F2)
val AccentRedText = Color(0xFFDE3737)
val AccentGreenText = Color(0xFF2E7D32)
val AccentBlueLight = Color(0xFFE8F1FC)

// Dark Theme minimal colors
val MinimalBackgroundDark = Color(0xFF12131A)
val MinimalSurfaceDark = Color(0xFF1E202B)
val MinimalTextLight = Color(0xFFE3E2E6)
val MinimalTextLightSecondary = Color(0xFFC4C6D0)
val MinimalBorderDark = Color(0xFF43474E)
