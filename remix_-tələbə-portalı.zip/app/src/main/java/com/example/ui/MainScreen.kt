package com.example.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Comment
import com.example.data.Document
import com.example.utils.Localization
import kotlinx.coroutines.launch

val AZERBAIJAN_UNIVERSITIES = listOf(
    "BDU", "UNEC", "AZMİU", "ADA", "BMU", "ADNSU", "AMU", "ADPU", "ADU", 
    "UFAZ", "BANM", "MAA", "ATU", "SDU", "GDU", "NKU", "LDU", "NDA", 
    "ARU", "AMK", "ADMİU", "Xəzər", "Qərbi Kaspi", "Odlar Yurdu"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppContent(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val loggedInUser = viewModel.loggedInUser
    val activeLanguage = viewModel.activeLanguage

    // Base Scaffold handles edge to edge layouts
    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            if (loggedInUser != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.background)
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            if (viewModel.selectedDocument != null) {
                                IconButton(
                                    onClick = { viewModel.selectDocument(null) },
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(MaterialTheme.colorScheme.surface, shape = CircleShape)
                                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, shape = CircleShape)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ArrowBack,
                                        contentDescription = "Back",
                                        tint = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            } else {
                                // Clean Minimalism left circular Brand box
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(MaterialTheme.colorScheme.primary, shape = CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "U",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 20.sp
                                    )
                                }
                            }

                            Column {
                                Text(
                                    text = "UniShare AZ",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Text(
                                    text = Localization.getString(activeLanguage, "app_title").uppercase(),
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = {
                                    viewModel.activeLanguage = if (viewModel.activeLanguage == Localization.LANG_AZ) {
                                        Localization.LANG_EN
                                    } else if (viewModel.activeLanguage == Localization.LANG_EN) {
                                        Localization.LANG_RU
                                    } else {
                                        Localization.LANG_AZ
                                    }
                                },
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(MaterialTheme.colorScheme.surface, shape = CircleShape)
                                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, shape = CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Translate,
                                    contentDescription = "Language",
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            IconButton(
                                onClick = { viewModel.selectedTab = AppTab.SETTINGS },
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(MaterialTheme.colorScheme.surface, shape = CircleShape)
                                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, shape = CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = "Profile",
                                    tint = if (viewModel.selectedTab == AppTab.SETTINGS) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        },
        bottomBar = {
            if (loggedInUser != null && viewModel.selectedDocument == null) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 0.dp,
                    modifier = Modifier
                        .border(width = 1.dp, color = MaterialTheme.colorScheme.outlineVariant)
                        .height(80.dp)
                ) {
                    NavigationBarItem(
                        selected = viewModel.selectedTab == AppTab.FEED,
                        onClick = { viewModel.selectedTab = AppTab.FEED },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Feed") },
                        label = { Text("Ana Səhifə", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            unselectedIconColor = MaterialTheme.colorScheme.secondary,
                            unselectedTextColor = MaterialTheme.colorScheme.secondary,
                            indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                        ),
                        modifier = Modifier.testTag("nav_feed")
                    )

                    NavigationBarItem(
                        selected = viewModel.selectedTab == AppTab.AI_ASSISTANT,
                        onClick = { viewModel.selectedTab = AppTab.AI_ASSISTANT },
                        icon = { Icon(Icons.Default.Forum, contentDescription = "AI Assistant") },
                        label = { Text("Chat", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            unselectedIconColor = MaterialTheme.colorScheme.secondary,
                            unselectedTextColor = MaterialTheme.colorScheme.secondary,
                            indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                        ),
                        modifier = Modifier.testTag("nav_ai")
                    )

                    // Unified Central Upload Floating Button Action Inside Bottom bar
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        contentAlignment = Alignment.Center
                    ) {
                        FloatingActionButton(
                            onClick = { viewModel.selectedTab = AppTab.UPLOAD },
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .size(56.dp)
                                .offset(y = (-10).dp)
                                .testTag("nav_upload")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Upload", modifier = Modifier.size(28.dp))
                        }
                    }

                    NavigationBarItem(
                        selected = viewModel.selectedTab == AppTab.SETTINGS,
                        onClick = { viewModel.selectedTab = AppTab.SETTINGS },
                        icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                        label = { Text("Ayarlar", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            unselectedIconColor = MaterialTheme.colorScheme.secondary,
                            unselectedTextColor = MaterialTheme.colorScheme.secondary,
                            indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                        ),
                        modifier = Modifier.testTag("nav_settings")
                    )
                }
            }
        }
    ) { paddingValues ->
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            color = MaterialTheme.colorScheme.background
        ) {
            if (loggedInUser == null) {
                AuthScreen(viewModel = viewModel)
            } else if (viewModel.activeReadingDocument != null) {
                BookReaderScreen(viewModel = viewModel, doc = viewModel.activeReadingDocument!!, onBack = { viewModel.activeReadingDocument = null })
            } else if (viewModel.selectedDocument != null) {
                DocumentDetailScreen(viewModel = viewModel, doc = viewModel.selectedDocument!!)
            } else {
                when (viewModel.selectedTab) {
                    AppTab.FEED -> FeedScreen(viewModel = viewModel)
                    AppTab.UPLOAD -> UploadScreen(viewModel = viewModel)
                    AppTab.AI_ASSISTANT -> AiAssistantScreen(viewModel = viewModel)
                    AppTab.SETTINGS -> SettingsScreen(viewModel = viewModel)
                }
            }
        }
    }
}

// ---------------------- 1. LOGIN / REGISTER SCREEN ----------------------
@Composable
fun AuthScreen(viewModel: MainViewModel) {
    val activeLang = viewModel.activeLanguage
    var emailOrPhone by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var university by remember { mutableStateOf("BDU") }
    var faculty by remember { mutableStateOf("") }
    var specialty by remember { mutableStateOf("") }

    var errorMessage by remember { mutableStateOf("") }
    var successMessage by remember { mutableStateOf("") }

    val unis = AZERBAIJAN_UNIVERSITIES
    var showUniDropdown by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f),
                        MaterialTheme.colorScheme.background
                    )
                )
            )
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
                .testTag("auth_card"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // University Portal Aesthetic Circle Header
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.School,
                        contentDescription = "EduAz Icon",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = Localization.getString(activeLang, "app_title"),
                    fontWeight = FontWeight.Bold,
                    fontSize = 24.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = Localization.getString(activeLang, "tagline"),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Standard Segmented Control for SignIn vs SignUp
                TabRow(
                    selectedTabIndex = if (viewModel.isRegisterMode) 1 else 0,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                ) {
                    Tab(
                        selected = !viewModel.isRegisterMode,
                        onClick = {
                            viewModel.isRegisterMode = false
                            errorMessage = ""
                            successMessage = ""
                        },
                        text = { Text(Localization.getString(activeLang, "sign_in"), fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = viewModel.isRegisterMode,
                        onClick = {
                            viewModel.isRegisterMode = true
                            errorMessage = ""
                            successMessage = ""
                        },
                        text = { Text(Localization.getString(activeLang, "sign_up"), fontWeight = FontWeight.Bold) }
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                if (errorMessage.isNotEmpty()) {
                    Text(
                        text = errorMessage,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
                if (successMessage.isNotEmpty()) {
                    Text(
                        text = successMessage,
                        color = Color(0xFF2E7D32),
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }

                // COMMON FIELDS
                if (viewModel.isRegisterMode) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text(Localization.getString(activeLang, "full_name")) },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth().testTag("reg_name_input"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }

                OutlinedTextField(
                    value = emailOrPhone,
                    onValueChange = { emailOrPhone = it },
                    label = { Text(Localization.getString(activeLang, "email") + " / " + Localization.getString(activeLang, "phone")) },
                    leadingIcon = { Icon(Icons.Default.MailOutline, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth().testTag("auth_cred_input"),
                    singleLine = true,
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text(Localization.getString(activeLang, "password")) },
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth().testTag("auth_pass_input"),
                    singleLine = true,
                )

                if (viewModel.isRegisterMode) {
                    Spacer(modifier = Modifier.height(10.dp))

                    // Simulated Dropdown selector for University
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = university,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text(Localization.getString(activeLang, "university")) },
                            leadingIcon = { Icon(Icons.Default.School, contentDescription = null) },
                            trailingIcon = {
                                IconButton(onClick = { showUniDropdown = !showUniDropdown }) {
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                        DropdownMenu(
                            expanded = showUniDropdown,
                            onDismissRequest = { showUniDropdown = false },
                            modifier = Modifier.fillMaxWidth(0.8f)
                        ) {
                            unis.forEach { item ->
                                DropdownMenuItem(
                                    text = { Text(item) },
                                    onClick = {
                                        university = item
                                        showUniDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = faculty,
                            onValueChange = { faculty = it },
                            label = { Text(Localization.getString(activeLang, "faculty")) },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = specialty,
                            onValueChange = { specialty = it },
                            label = { Text(Localization.getString(activeLang, "specialty")) },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = {
                        errorMessage = ""
                        successMessage = ""
                        if (viewModel.isRegisterMode) {
                            val err = viewModel.handleRegister(
                                name = name,
                                email = emailOrPhone,
                                phone = emailOrPhone,
                                pass = password,
                                uni = university,
                                fac = faculty,
                                spec = specialty
                            )
                            if (err != null) {
                                errorMessage = err
                            } else {
                                successMessage = Localization.getString(activeLang, "register_success")
                            }
                        } else {
                            val err = viewModel.handleLogin(emailOrPhone, password)
                            if (err != null) {
                                errorMessage = err
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("auth_submit_btn"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = if (viewModel.isRegisterMode) Localization.getString(activeLang, "sign_up") else Localization.getString(activeLang, "sign_in"),
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            }
        }
    }
}

@Composable
fun GeminiBannerCard(onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("gemini_banner_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(Color(0xFF005FB8), Color(0xFF004A8F))
                    )
                )
                .padding(18.dp)
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "Gemini",
                        tint = Color(0xFFA8C7FA),
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "GEMINI AI",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFA8C7FA),
                        letterSpacing = 1.5.sp
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Akademik sualın var? Süni İntellekt köməkçisindən soruş.",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

// ---------------------- 2. UNIVERSITY FEED / DOCUMENT LIST ----------------------
@Composable
fun FeedScreen(viewModel: MainViewModel) {
    val activeLang = viewModel.activeLanguage
    val docsList by viewModel.documents.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    
    val unis = listOf("Bütün Universitetlər") + AZERBAIJAN_UNIVERSITIES
    
    val filtered = docsList.filter {
        it.basliq.contains(searchQuery, ignoreCase = true) ||
        it.aciqlama.contains(searchQuery, ignoreCase = true) ||
        it.fənn.contains(searchQuery, ignoreCase = true) ||
        it.ixtisas.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Search bar with clean minimalism design
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text(Localization.getString(activeLang, "search_documents"), fontSize = 14.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.secondary) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Default.Clear, contentDescription = null)
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_bar"),
            shape = RoundedCornerShape(24.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                focusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                unfocusedBorderColor = Color(0xFFF0F2F5)
            )
        )

        // Large Horizontal scroll of universities row
        Column {
            Text(
                text = Localization.getString(activeLang, "filter_uni"),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(bottom = 6.dp)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Display all Azerbaijan universities dynamically with beautiful scrolling chips
                unis.forEach { item ->
                    val localizedItem = if (item == "Bütün Universitetlər") Localization.getString(activeLang, "all_unis") else item
                    val selected = viewModel.activeUniFilter == item
                    
                    Button(
                        onClick = { viewModel.setUniversityFilter(item) },
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selected) MaterialTheme.colorScheme.primary else Color(0xFFF0F2F5),
                            contentColor = if (selected) Color.White else MaterialTheme.colorScheme.secondary
                        ),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        modifier = Modifier
                            .height(36.dp)
                            .testTag("filter_$item")
                    ) {
                        Text(localizedItem, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Clean interactive AI Banner
        GeminiBannerCard {
            viewModel.selectedTab = AppTab.AI_ASSISTANT
        }

        // Recent documents list
        Text(
            text = Localization.getString(activeLang, "recent_uploads") + " (${filtered.size})",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
        )

        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.FolderOpen,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = Localization.getString(activeLang, "no_documents"),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("documents_list"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filtered) { doc ->
                    DocumentCard(doc = doc, viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun DocumentCard(doc: Document, viewModel: MainViewModel) {
    val activeLang = viewModel.activeLanguage
    var authorName by remember { mutableStateOf("") }
    
    LaunchedEffect(doc.id) {
        viewModel.getAuthorName(doc.yukleyenUserId) { name ->
            authorName = name
        }
    }

    val extension = doc.faylYolu.substringAfterLast(".").uppercase()
    val isPdf = extension == "PDF"
    
    // Choose colors dynamically based on document extension
    val formatBg = if (isPdf) Color(0xFFFDF2F2) else Color(0xFFE8F1FC)
    val formatText = if (isPdf) Color(0xFFDE3737) else Color(0xFF005FB8)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("document_card_${doc.id}")
            .clickable { viewModel.selectDocument(doc) },
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Color(0xFFF0F2F5)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // File type indicator square box
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(formatBg, shape = RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = extension.take(4),
                    color = formatText,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }

            // Description column
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = doc.basliq,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "${doc.universitet} • ${doc.fənn} • ${doc.faylOlcusu} MB",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.8f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Upvote indicators on the right side
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                val voteResult = doc.upvoteSayi - doc.downvoteSayi
                val voteText = if (voteResult >= 0) "+$voteResult" else "$voteResult"
                val voteColor = if (voteResult >= 0) Color(0xFF2E7D32) else Color(0xFFDE3737)

                Text(
                    text = voteText,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = voteColor
                )

                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "Details",
                    tint = MaterialTheme.colorScheme.secondary.copy(alpha = 0.6f),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

// ---------------------- 3. DOCUMENT DETAILS & COMMENTS ----------------------
@Composable
fun DocumentDetailScreen(viewModel: MainViewModel, doc: Document) {
    val activeLang = viewModel.activeLanguage
    val commentsList by viewModel.comments.collectAsState()
    var commentInput by remember { mutableStateOf("") }
    var authorName by remember { mutableStateOf("") }
    
    LaunchedEffect(doc.id) {
        viewModel.getAuthorName(doc.yukleyenUserId) { name ->
            authorName = name
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Main detail card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // University pill
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = doc.universitet,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    // Format
                    val extension = doc.faylYolu.substringAfterLast(".").uppercase()
                    Text(
                        text = "$extension • ${doc.faylOlcusu} MB",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = doc.basliq,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "${Localization.getString(activeLang, "subject")}: ${doc.fənn}",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = doc.aciqlama,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = { viewModel.activeReadingDocument = doc },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_read_book_mode"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = Color.White
                    ),
                    contentPadding = PaddingValues(vertical = 12.dp)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = "Read",
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "📖 SANKİ KİTABDAN OXU",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Metadata list
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                Spacer(modifier = Modifier.height(10.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Yükləyən: $authorName",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "UUID: ${doc.faylYolu}",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(
                            onClick = { viewModel.upvoteSelected() },
                            modifier = Modifier.testTag("btn_upvote")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.ThumbUp, contentDescription = "Upvote", tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("${doc.upvoteSayi}", fontSize = 12.sp)
                            }
                        }
                        IconButton(
                            onClick = { viewModel.downvoteSelected() },
                            modifier = Modifier.testTag("btn_downvote")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.ThumbDown, contentDescription = "Downvote", tint = MaterialTheme.colorScheme.error)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("${doc.downvoteSayi}", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Comments header
        Text(
            text = Localization.getString(activeLang, "comments_title") + " (${commentsList.size})",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        // Comments list
        if (commentsList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = Localization.getString(activeLang, "no_comments"),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("comments_list"),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(commentsList) { comm ->
                    CommentBubble(comm = comm, viewModel = viewModel)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Comment writing box
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = commentInput,
                onValueChange = { commentInput = it },
                placeholder = { Text(Localization.getString(activeLang, "write_comment")) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("input_comment"),
                shape = RoundedCornerShape(12.dp),
                maxLines = 2
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = {
                    if (commentInput.isNotEmpty()) {
                        viewModel.submitComment(commentInput)
                        commentInput = ""
                    }
                },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary)
                    .testTag("btn_comment_submit")
            ) {
                Icon(Icons.Default.Send, contentDescription = "Send", tint = MaterialTheme.colorScheme.onPrimary)
            }
        }
    }
}

@Composable
fun CommentBubble(comm: Comment, viewModel: MainViewModel) {
    var authorName by remember { mutableStateOf("") }
    
    LaunchedEffect(comm.userId) {
        viewModel.getAuthorName(comm.userId) { name ->
            authorName = name
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = authorName,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Tələbə",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = comm.metn,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

// ---------------------- 4a. IMMERSIVE PHYSICAL BOOK READER SIMULATION (Requirement 1) ----------------------
@Composable
fun BookReaderScreen(viewModel: MainViewModel, doc: Document, onBack: () -> Unit) {
    val pages = remember(doc.id) { generateBookPages(doc) }
    // Using foundation pager
    val pagerState = rememberPagerState(pageCount = { pages.size })
    val coroutineScope = rememberCoroutineScope()

    // Themes configuration
    var selectedThemeIdx by remember { mutableStateOf(0) } // 0: Sepia, 1: White, 2: Night
    val themes = listOf(
        // Sepia
        Triple(Color(0xFFF4ECD8), Color(0xFF2C221E), "Sepia 📜"),
        // White
        Triple(Color(0xFFFCFAF2), Color(0xFF1E2022), "Ağ ☀️"),
        // Night
        Triple(Color(0xFF1C1A17), Color(0xFFE2E0D9), "Gece 🌙")
    )
    val (bgColor, textColor, themeLabel) = themes[selectedThemeIdx]

    // Font size configurations
    var fontScale by remember { mutableStateOf(16f) }

    // Bookmarked states
    var bookmarkedPages by remember { mutableStateOf(setOf<Int>()) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(bgColor)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Header bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Geri", tint = textColor)
                }

                Column(
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = doc.basliq,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = textColor,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = doc.fənn,
                        style = MaterialTheme.typography.bodySmall,
                        color = textColor.copy(alpha = 0.6f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Bookmark Ribbon icon
                val isBookmarked = bookmarkedPages.contains(pagerState.currentPage)
                IconButton(
                    onClick = {
                        bookmarkedPages = if (isBookmarked) {
                            bookmarkedPages - pagerState.currentPage
                        } else {
                            bookmarkedPages + pagerState.currentPage
                        }
                    }
                ) {
                    Icon(
                        imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                        contentDescription = "Bookmark",
                        tint = if (isBookmarked) Color(0xFFE65100) else textColor
                    )
                }
            }

            // Top controller bar inside Book: FontSize (A- & A+) and Theme selects
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .background(textColor.copy(alpha = 0.05f), shape = RoundedCornerShape(12.dp))
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Font Adjustment
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(
                        onClick = { if (fontScale > 12f) fontScale -= 2f },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Text("A-", color = textColor, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Text(
                        text = "${fontScale.toInt()}px",
                        style = MaterialTheme.typography.labelMedium,
                        color = textColor,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(
                        onClick = { if (fontScale < 28f) fontScale += 2f },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Text("A+", color = textColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }

                // Color Themes selector
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    themes.forEachIndexed { idx, item ->
                        val isSelected = selectedThemeIdx == idx
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(item.first)
                                .border(
                                    width = if (isSelected) 3.dp else 1.dp,
                                    color = if (isSelected) Color(0xFFE65100) else textColor.copy(alpha = 0.3f),
                                    shape = CircleShape
                                )
                                .clickable { selectedThemeIdx = idx }
                        )
                    }
                }
            }

            // Book Pager Canvas
            HorizontalPager(
                state = pagerState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(16.dp)
            ) { pageIdx ->
                val page = pages[pageIdx]
                
                // Realistic Page design with hardcover line on left or page texture
                Card(
                    modifier = Modifier
                        .fillMaxSize(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = bgColor),
                    border = BorderStroke(1.dp, textColor.copy(alpha = 0.15f))
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        // Book gutter fold effect on left margin
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .width(8.dp)
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            textColor.copy(alpha = 0.12f),
                                            Color.Transparent
                                        )
                                    )
                                )
                        )

                        // Actual text content
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 24.dp, vertical = 20.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = page.title,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = textColor,
                                    fontFamily = FontFamily.Serif
                                )
                                
                                if (bookmarkedPages.contains(pageIdx)) {
                                    Icon(
                                        imageVector = Icons.Default.Bookmark,
                                        contentDescription = "Saved",
                                        tint = Color(0xFFE65100),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            HorizontalDivider(color = textColor.copy(alpha = 0.1f))

                            Text(
                                text = page.content,
                                fontSize = fontScale.sp,
                                color = textColor,
                                fontFamily = FontFamily.Serif,
                                lineHeight = (fontScale * 1.5).sp,
                                modifier = Modifier
                                    .weight(1f)
                                    .verticalScroll(rememberScrollState())
                            )
                        }
                    }
                }
            }

            // Footer / Scrub slider bar
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Səhifə ${pagerState.currentPage + 1} / ${pages.size}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = textColor
                    )
                    
                    Text(
                        text = if (bookmarkedPages.isNotEmpty()) "📌 ${bookmarkedPages.size} Əlfəcin" else "Əlfəcin yoxdur",
                        fontSize = 11.sp,
                        color = textColor.copy(alpha = 0.6f)
                    )
                }

                Slider(
                    value = pagerState.currentPage.toFloat(),
                    onValueChange = { pageVal ->
                        coroutineScope.launch {
                            pagerState.scrollToPage(pageVal.toInt())
                        }
                    },
                    valueRange = 0f..(pages.size - 1).coerceAtLeast(1).toFloat(),
                    colors = SliderDefaults.colors(
                        thumbColor = textColor,
                        activeTrackColor = textColor,
                        inactiveTrackColor = textColor.copy(alpha = 0.2f)
                    )
                )

                // Swipe tutorial tip
                Text(
                    text = "Kitab vərəqləri kimi sürüşdürün • ${themeLabel}",
                    style = MaterialTheme.typography.labelSmall,
                    color = textColor.copy(alpha = 0.4f),
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }
    }
}

// ---------------------- 4. INTERACTIVE FILE UPLOADER ----------------------
@Composable
fun UploadScreen(viewModel: MainViewModel) {
    val activeLang = viewModel.activeLanguage
    val context = LocalContext.current
    
    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf("") }
    var specialty by remember { mutableStateOf("") }
    var university by remember { mutableStateOf("BDU") }
    var extType by remember { mutableStateOf("PDF") }
    
    // Auto-detection states (Requirement 3)
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedFileName by remember { mutableStateOf("") }
    var detectedFileSize by remember { mutableStateOf(0.0) } // Learned from Uri auto-detected size

    var errorMsg by remember { mutableStateOf("") }
    var successMsg by remember { mutableStateOf("") }

    val unis = AZERBAIJAN_UNIVERSITIES
    var showUniDropdown by remember { mutableStateOf(false) }

    // Pick PDF Launcher
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedUri = uri
            val (name, size) = getUriNameAndSize(context, uri)
            selectedFileName = name
            detectedFileSize = size
            
            // Auto extract extension
            val ext = name.substringAfterLast(".", "PDF").uppercase()
            extType = if (ext.length in 2..5) ext else "PDF"
            errorMsg = ""
        }
    }

    // Storage Permission Launcher (Requirement 3)
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            // Launch selection directly
            try {
                filePickerLauncher.launch("application/pdf")
            } catch (e: Exception) {
                errorMsg = "Pdf seçici işə salına bilmədi: ${e.localizedMessage}"
            }
        } else {
            errorMsg = "Cihazın daxili yaddaşına daxil olmaq üçün icazə tələb olunur."
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = Localization.getString(activeLang, "upload_document"),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Daxili yaddaşdan istənilən ölçüdə PDF sənədini seçib yükləyin. Ölçü avtomatik təyin ediləcək.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            if (errorMsg.isNotEmpty()) {
                Text(
                    text = errorMsg,
                    color = MaterialTheme.colorScheme.error,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(vertical = 4.dp).testTag("upload_err")
                )
            }
            if (successMsg.isNotEmpty()) {
                Text(
                    text = successMsg,
                    color = Color(0xFF2E7D32),
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(vertical = 4.dp).testTag("upload_success")
                )
            }
        }

        // Beautiful Interactive SAF Area (Requirement 3)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        // Check or Request storage permission before accessing internal storage
                        val hasPermission = androidx.core.content.ContextCompat.checkSelfPermission(
                            context,
                            android.Manifest.permission.READ_EXTERNAL_STORAGE
                        ) == android.content.pm.PackageManager.PERMISSION_GRANTED

                        if (hasPermission) {
                            filePickerLauncher.launch("application/pdf")
                        } else {
                            permissionLauncher.launch(android.Manifest.permission.READ_EXTERNAL_STORAGE)
                        }
                    },
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(2.dp, Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), Color(0xFF005FB8).copy(alpha = 0.5f)))),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (selectedUri == null) {
                        Icon(
                            imageVector = Icons.Default.Folder,
                            contentDescription = "Pick PDF from Storage",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(54.dp)
                        )
                        Text(
                            text = "PDF sənədi yükləmək üçün daxili yaddaşa giriş izni al və faylı seç",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Hər hansı ölçüdə PDF sənədi dəstəklənir",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    } else {
                        // Dynamically render the auto-detected PDF details
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(Color(0xFFFDF2F2), shape = RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = extType,
                                color = Color(0xFFDE3737),
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                        Text(
                            text = selectedFileName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            textAlign = TextAlign.Center,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            SuggestionChip(
                                onClick = {},
                                label = { Text(String.format("Avtomatik Ölçü: %.2f MB", detectedFileSize), fontWeight = FontWeight.Bold) }
                            )
                            IconButton(onClick = {
                                selectedUri = null
                                selectedFileName = ""
                                detectedFileSize = 0.0
                            }) {
                                Icon(Icons.Default.Delete, contentDescription = "Remove", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }

        item {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text(Localization.getString(activeLang, "title")) },
                placeholder = { Text("Məs: Xətti Cəbr mühazirə qeydləri") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("upload_title"),
                singleLine = true
            )
        }

        item {
            OutlinedTextField(
                value = desc,
                onValueChange = { desc = it },
                label = { Text(Localization.getString(activeLang, "description")) },
                placeholder = { Text("Sənəd barədə qısa məlumat yazın...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp)
                    .testTag("upload_desc"),
                maxLines = 4
            )
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text(Localization.getString(activeLang, "subject")) },
                    placeholder = { Text(Localization.getString(activeLang, "subject_placeholder")) },
                    modifier = Modifier
                        .weight(1.0f)
                        .testTag("upload_subject"),
                    singleLine = true
                )
                OutlinedTextField(
                    value = specialty,
                    onValueChange = { specialty = it },
                    label = { Text(Localization.getString(activeLang, "specialty")) },
                    placeholder = { Text("Komputer Müh.") },
                    modifier = Modifier.weight(1.0f),
                    singleLine = true
                )
            }
        }

        item {
            // Select University Dropdown with Azerbaijan List
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = university,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text(Localization.getString(activeLang, "university")) },
                    leadingIcon = { Icon(Icons.Default.School, contentDescription = null) },
                    trailingIcon = {
                        IconButton(onClick = { showUniDropdown = !showUniDropdown }) {
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                DropdownMenu(
                    expanded = showUniDropdown,
                    onDismissRequest = { showUniDropdown = false },
                    modifier = Modifier.fillMaxWidth(0.9f)
                ) {
                    unis.forEach { item ->
                        DropdownMenuItem(
                            text = { Text(item) },
                            onClick = {
                                university = item
                                showUniDropdown = false
                            }
                        )
                    }
                }
            }
        }

        // Submit Button
        item {
            Button(
                onClick = {
                    errorMsg = ""
                    successMsg = ""
                    
                    if (selectedUri == null) {
                        errorMsg = "Zəhmət olmasa daxili yaddaşdan yükləmək üçün sənəd sən kənarda saxla."
                        return@Button
                    }
                    if (title.isBlank() || desc.isBlank() || subject.isBlank()) {
                        errorMsg = "Zəhmət olmasa bütün sahələri doldurun."
                        return@Button
                    }

                    // Perform Upload with exact dynamic file size parsed from selected Uri
                    val err = viewModel.performUpload(
                        title = title,
                        desc = desc,
                        subject = subject,
                        uni = university,
                        spec = specialty,
                        fileType = extType,
                        fileSizeMb = detectedFileSize
                    )
                    if (err != null) {
                        errorMsg = err
                    } else {
                        successMsg = Localization.getString(activeLang, "success_uploaded")
                        // Clear Inputs on successful upload
                        title = ""
                        desc = ""
                        subject = ""
                        specialty = ""
                        selectedUri = null
                        selectedFileName = ""
                        detectedFileSize = 0.0
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("upload_submit_btn"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.CloudUpload, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(Localization.getString(activeLang, "submit"), fontWeight = FontWeight.Bold)
            }
        }
    }
}

// ---------------------- 5. GEMINI POWERED CHATBOT RECIPROCAL INTERFACE ----------------------
@Composable
fun AiAssistantScreen(viewModel: MainViewModel) {
    val activeLang = viewModel.activeLanguage
    val chatList by viewModel.chatMessages.collectAsState()
    var promptInput by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    LaunchedEffect(chatList.size) {
        if (chatList.isNotEmpty()) {
            scope.launch {
                listState.animateScrollToItem(chatList.size - 1)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // AI Guide Header banner
        Card(
            modifier = Modifier.fillMaxWidth().testTag("ai_header_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "AI Logo",
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = Localization.getString(activeLang, "ai_assistant"),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyLarge
                    )
                    Text(
                        text = "Süni İntellekt rəhbərliyi (Gemini + Local Fallback)",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Chat lists scroll
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .testTag("chat_messages_column"),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(chatList) { msg ->
                val isUser = msg.sender == "user"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                ) {
                    if (!isUser) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "AI",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .size(24.dp)
                                .padding(end = 4.dp)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(
                                RoundedCornerShape(
                                    topStart = 16.dp,
                                    topEnd = 16.dp,
                                    bottomStart = if (isUser) 16.dp else 0.dp,
                                    bottomEnd = if (isUser) 0.dp else 16.dp
                                )
                            )
                            .background(
                                if (isUser) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                            .padding(14.dp)
                            .widthIn(max = 280.dp)
                    ) {
                        Text(
                            text = msg.text,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (isUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            if (viewModel.aiLoading) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Aİ cavab hazırlayır...",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Send bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = promptInput,
                onValueChange = { promptInput = it },
                placeholder = { Text(Localization.getString(activeLang, "ai_assistant_hint")) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("chat_input_text"),
                shape = RoundedCornerShape(12.dp),
                maxLines = 3
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = {
                    if (promptInput.isNotEmpty() && !viewModel.aiLoading) {
                        viewModel.handleSendChatMessage(promptInput)
                        promptInput = ""
                    }
                },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(
                        if (promptInput.isEmpty() || viewModel.aiLoading) MaterialTheme.colorScheme.outlineVariant
                        else MaterialTheme.colorScheme.primary
                    )
                    .testTag("chat_send_button")
            ) {
                Icon(
                    Icons.Default.Send,
                    contentDescription = "Send Prompt",
                    tint = if (promptInput.isEmpty() || viewModel.aiLoading) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f) else MaterialTheme.colorScheme.onPrimary
                )
            }
        }
    }
}

// ---------------------- 6. PROFILE & SETTINGS CONFIGURATION (Modul 4) ----------------------
@Composable
fun SettingsScreen(viewModel: MainViewModel) {
    val activeLang = viewModel.activeLanguage
    val user = viewModel.loggedInUser ?: return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Author profile header
        Card(
            modifier = Modifier.fillMaxWidth().testTag("profile_badge"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (viewModel.isAnonymousMode) "A" else user.tamAd.take(1).uppercase(),
                            fontWeight = FontWeight.Bold,
                            fontSize = 22.sp,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Text(
                            text = if (viewModel.isAnonymousMode) Localization.getString(activeLang, "anonymous_user") else user.tamAd,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "${user.universitet} • ${user.ixtisas}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        }

        // Toggles list
        Text(
            text = Localization.getString(activeLang, "settings"),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        // Switch 1: Dark Mode Theme Toggle
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (viewModel.isDarkTheme) Localization.getString(activeLang, "dark_mode") else Localization.getString(activeLang, "light_mode"),
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Arxa fon rənglərini tənzimləyin",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = viewModel.isDarkTheme,
                    onCheckedChange = { viewModel.updateTheme(it) },
                    modifier = Modifier.testTag("switch_dark_theme")
                )
            }
        }

        // Switch 2: Anonymous Privacy Mode Toggle (Modul 2)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = Localization.getString(activeLang, "anonymous_mode"),
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = Localization.getString(activeLang, "anonymous_desc"),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = viewModel.isAnonymousMode,
                    onCheckedChange = { viewModel.updateAnonymity(it) },
                    modifier = Modifier.testTag("switch_anoymous")
                )
            }
        }

        // Language Selectors (Modul 4)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = Localization.getString(activeLang, "choose_lang"),
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val langs = listOf(
                        Localization.LANG_AZ to "AZ 🇦🇿",
                        Localization.LANG_TR to "TR 🇹🇷",
                        Localization.LANG_RU to "RU 🇷🇺",
                        Localization.LANG_EN to "EN 🇬🇧"
                    )
                    langs.forEach { (code, label) ->
                        val active = viewModel.activeLanguage == code
                        SuggestionChip(
                            onClick = { viewModel.updateLanguage(code) },
                            label = { Text(label, fontWeight = FontWeight.Bold) },
                            border = SuggestionChipDefaults.suggestionChipBorder(
                                enabled = true,
                                borderColor = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                            ),
                            colors = SuggestionChipDefaults.suggestionChipColors(
                                containerColor = if (active) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
                            ),
                            modifier = Modifier.testTag("lang_btn_$code")
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // Log out button
        Button(
            onClick = { viewModel.handleLogout() },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("btn_logout"),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
        ) {
            Icon(Icons.Default.Logout, contentDescription = "Exit")
            Spacer(modifier = Modifier.width(8.dp))
            Text(Localization.getString(activeLang, "logout"), fontWeight = FontWeight.Bold)
        }
    }
}

// ---------------------- 5. HELPERS & BOOK STRUCTURES ----------------------
data class BookPage(val title: String, val content: String)

fun generateBookPages(doc: Document): List<BookPage> {
    val topic = doc.fənn.ifBlank { doc.basliq }
    return listOf(
        BookPage(
            title = "Fəsil 1: Giriş",
            content = "Bu dərslik '${doc.basliq}' mövzusunu dərindən öyrənmək üçün tərtib edilmişdir. Sənədin fənni/sahəsi '${doc.fənn}' olaraq müəyyən olunub və bu mövzuda olan nəzəri və praktiki baza prinsiplərini əks etdirir.\n\nPreambula:\nAli təhsil müddətində tələbələrin bu tip konspektləri oxuması, onların mühazirə və laboratoriya dərslərini daha yaxşı mənimsəməsinə şərait yaradır. Aşağıdakı bölmələrdə əsas tədqiqat və öyrənmə metodlarından bəhs ediləcək."
        ),
        BookPage(
            title = "Fəsil 2: Fundamental Nəzəriyyə",
            content = "Mövzu: ${topic} üzrə nəzəriyyələr.\n\nUğurlu mənimsəmə üçün aşağıdakı təlimatlara əməl edilməsi tövsiyə olunur:\n1. Hər bir yeni terminin izahını diqqətlə nəzərdən keçirin.\n2. Sənəddə verilən xüsusi qeydləri ayrıca dəftərinizdə qeyd edin.\n3. Praktiki mövzuları mütləq şəkildə laboratoriya və ya seminar dərslərində tətbiq edin.\n\nBu sənəd həmçinin '${doc.universitet}' daxili imtahan proqramına uyğun hazırlanıb."
        ),
        BookPage(
            title = "Fəsil 3: Praktiki Laboratoriya və Tətbiq",
            content = "Praktika hər bir dərsin ən fundamental hissəsidir. '${topic}' mövzusuna aid ilk tətbiqi tapşırıqlar aşağıdakı kimidir:\n\n- Tapşırıq A: Verilmiş modelin quruluş sxemini təhlil edin və müvafiq parametrləri daxil edin.\n- Tapşırıq B: Nəticələrin doğruluğunu müqayisəli analiz üsulu ilə qiymətləndirin və qrafikləşdirin.\n\nHər hansı sualınız olduqda, sənəd qeydləri bölməsində rəy yaza bilərsiniz."
        ),
        BookPage(
            title = "Fəsil 4: İmtahan Hazırlığı və Suallar",
            content = "Aşağıdakı nümunəvi sualları sərbəst şəkildə cavablandırmağa çalışın:\n\n1. Sənədin əhatə etdiyi ana fikrin məqsədi nədir?\n2. Mövzunun praktiki tətbiqində ən çox qarşıya çıxan çətinliklər hansılardır?\n3. Müasir elmi yanaşmalar bu mövzu haqqında hansı fikirdədir?\n\nBu sualların cavabları sizin imtahanda yüksək bal toplamağınıza birbaşa kömək edəcəkdir."
        ),
        BookPage(
            title = "Fəsil 5: Xülasə, Qrafik Analiz və Ədəbiyyat",
            content = "Bu sənədin ərsəyə gəlməsində əməyi keçən hər kəsə, xüsusən də yükləyən tələbə yoldaşımıza təşəkkür edirik!\n\nMəqalələr və dərsliklər bazasında öz mövqeyini qoruyan bu mükəmməl konspekt, həmçinin digər universitet tələbələri üçün də açıq resursdur.\n\nTöhfə və elmi inkişafınızda sizə uğurlar arzulayırıq!\n\n-- SON --"
        )
    )
}

fun getUriNameAndSize(context: Context, uri: Uri): Pair<String, Double> {
    var name = "sened.pdf"
    var sizeMb = 1.0
    try {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (cursor.moveToFirst()) {
                if (nameIndex != -1) {
                    val rawName = cursor.getString(nameIndex)
                    if (!rawName.isNullOrEmpty()) {
                        name = rawName
                    }
                }
                if (sizeIndex != -1) {
                    val sizeBytes = cursor.getLong(sizeIndex)
                    sizeMb = sizeBytes.toDouble() / (1024 * 1024)
                }
            }
        }
    } catch (e: Exception) {
        Log.e("UploadScreen", "Cannot resolve Uri info", e)
    }
    return Pair(name, sizeMb)
}

