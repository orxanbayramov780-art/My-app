package com.example.ui

import android.app.Application
import android.content.Context
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.api.GeminiClient
import com.example.data.AppDatabase
import com.example.data.Comment
import com.example.data.Document
import com.example.data.StudentRepository
import com.example.data.User
import com.example.utils.Localization
import com.example.utils.SecurityUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

enum class AppTab {
    FEED, UPLOAD, AI_ASSISTANT, SETTINGS
}

data class ChatMessage(
    val sender: String, // "user" or "ai" or "system"
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: StudentRepository
    private val context: Context = application.applicationContext

    // Screen navigation state
    var selectedTab by mutableStateOf(AppTab.FEED)
    var selectedDocument: Document? by mutableStateOf(null)
    var activeReadingDocument: Document? by mutableStateOf(null)
    
    // Auth States
    var loggedInUser: User? by mutableStateOf(null)
    var isRegisterMode by mutableStateOf(false)

    // General app states
    var activeLanguage by mutableStateOf(Localization.LANG_AZ)
    var isDarkTheme by mutableStateOf(false)
    var isAnonymousMode by mutableStateOf(false)
    var activeUniFilter by mutableStateOf("Bütün Universitetlər") // Default filter

    // Documents Flow
    private val _documents = MutableStateFlow<List<Document>>(emptyList())
    val documents: StateFlow<List<Document>> = _documents.asStateFlow()

    // Selected Document Comments Flow
    private val _comments = MutableStateFlow<List<Comment>>(emptyList())
    val comments: StateFlow<List<Comment>> = _comments.asStateFlow()

    // AI Chat History
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    var aiLoading by mutableStateOf(false)

    init {
        val database = AppDatabase.getDatabase(application)
        repository = StudentRepository(database)

        // Generate the upload directory securely
        try {
            val uploadDir = File(context.filesDir, "uploads")
            if (!uploadDir.exists()) {
                uploadDir.mkdirs()
            }
        } catch (e: Exception) {
            Log.e("MainViewModel", "Could not create uploads folder", e)
        }

        // Initialize documents collection
        observeDocuments()
        
        // Setup initial Chat greeting
        resetChat()
    }

    private fun observeDocuments() {
        viewModelScope.launch {
            try {
                repository.syncAllDocuments()
            } catch (e: Exception) {
                Log.e("MainViewModel", "syncAllDocuments failed", e)
            }
            repository.getAllDocuments().collect { docs ->
                filterDocuments(activeUniFilter, docs)
            }
        }
    }

    fun setUniversityFilter(uni: String) {
        activeUniFilter = uni
        viewModelScope.launch {
            try {
                repository.syncAllDocuments()
            } catch (e: Exception) {
                Log.e("MainViewModel", "syncAllDocuments failed on filter", e)
            }
            repository.getDocumentsByUniversity(uni).collect { docs ->
                _documents.value = docs
            }
        }
    }

    private fun filterDocuments(uni: String, allDocs: List<Document>) {
        if (uni == "Bütün Universitetlər" || uni == "All Universities" || uni == "Tüm Üniversiteler" || uni == "Все Университеты") {
            _documents.value = allDocs
        } else {
            _documents.value = allDocs.filter { it.universitet == uni }
        }
    }

    fun observeCommentsForSelectedDocument(docId: Int) {
        viewModelScope.launch {
            try {
                repository.syncComments(docId)
            } catch (e: Exception) {
                Log.e("MainViewModel", "syncComments failed on select", e)
            }
            repository.getCommentsForDocument(docId).collect { list ->
                _comments.value = list
            }
        }
    }

    fun selectDocument(doc: Document?) {
        selectedDocument = doc
        if (doc != null) {
            observeCommentsForSelectedDocument(doc.id)
            // Increment downloads when clicking/viewing or downloading
            viewModelScope.launch {
                repository.incrementDownload(doc.id)
                // Refresh local model download count
                selectedDocument = repository.getDocumentById(doc.id)
            }
        }
    }

    // AUTHENTICATION WORKFLOWS (Modul 2)
    fun handleLogin(credential: String, pass: String): String? {
        var errorMsg: String? = null
        viewModelScope.launch {
            // Check email first
            var user = repository.getUserByEmail(credential)
            if (user == null) {
                // Try phone
                user = repository.getUserByPhone(credential)
            }

            if (user != null && SecurityUtils.verifyPassword(pass, user.sifreHash)) {
                loggedInUser = user
                activeLanguage = user.secilmisDil
                isDarkTheme = user.secilmisTema == "dark"
                isAnonymousMode = user.isAnonymous
                // Synchronize active uni filter depending on user profile
                activeUniFilter = user.universitet
                setUniversityFilter(user.universitet)
                resetChat()
            } else {
                errorMsg = Localization.getString(activeLanguage, "error_invalid_credentials")
            }
        }
        return errorMsg
    }

    fun handleRegister(
        name: String,
        email: String,
        phone: String,
        pass: String,
        uni: String,
        fac: String,
        spec: String
    ): String? {
        if (name.isBlank() || email.isBlank() || phone.isBlank() || pass.isBlank() || uni.isBlank()) {
            return Localization.getString(activeLanguage, "error_empty_fields")
        }

        viewModelScope.launch {
            // Check duplicate
            val existingEmail = repository.getUserByEmail(email)
            val existingPhone = repository.getUserByPhone(phone)
            if (existingEmail != null || existingPhone != null) {
                // Already registered
                return@launch
            }

            val newUser = User(
                tamAd = name,
                email = email,
                telefonNomresi = phone,
                sifreHash = SecurityUtils.hashPassword(pass),
                universitet = uni,
                fakulte = fac,
                ixtisas = spec,
                secilmisDil = activeLanguage,
                secilmisTema = if (isDarkTheme) "dark" else "light",
                isAnonymous = isAnonymousMode
            )
            val insertedId = repository.insertUser(newUser)
            val loggedIn = repository.getUserById(insertedId.toInt())
            if (loggedIn != null) {
                loggedInUser = loggedIn
                activeUniFilter = loggedIn.universitet
                setUniversityFilter(loggedIn.universitet)
                resetChat()
            }
        }
        return null
    }

    fun handleLogout() {
        loggedInUser = null
        selectedDocument = null
        activeReadingDocument = null
        selectedTab = AppTab.FEED
        resetChat()
    }

    // USER SETTINGS UPDATES
    fun updateLanguage(lang: String) {
        activeLanguage = lang
        val user = loggedInUser ?: return
        viewModelScope.launch {
            val updated = user.copy(secilmisDil = lang)
            repository.updateUser(updated)
            loggedInUser = updated
        }
    }

    fun updateTheme(dark: Boolean) {
        isDarkTheme = dark
        val user = loggedInUser ?: return
        viewModelScope.launch {
            val updated = user.copy(secilmisTema = if (dark) "dark" else "light")
            repository.updateUser(updated)
            loggedInUser = updated
        }
    }

    fun updateAnonymity(anon: Boolean) {
        isAnonymousMode = anon
        val user = loggedInUser ?: return
        viewModelScope.launch {
            val updated = user.copy(isAnonymous = anon)
            repository.updateUser(updated)
            loggedInUser = updated
        }
    }

    // FILE UPLOADER OPERATIONS (Modul 3)
    fun performUpload(
        title: String,
        desc: String,
        subject: String,
        uni: String,
        spec: String,
        fileType: String, // "PDF", "DOCX", "PNG", "JPG"
        fileSizeMb: Double
    ): String? {
        if (title.isBlank() || desc.isBlank() || subject.isBlank() || uni.isBlank()) {
            return Localization.getString(activeLanguage, "error_empty_fields")
        }

        // 1. Validation size limit: Max 50MB (Constraint check)
        if (fileSizeMb > 50.0) {
            return Localization.getString(activeLanguage, "max_size_error")
        }

        // 2. Format validation check
        val allowedTypes = listOf("PDF", "DOCX", "PNG", "JPG")
        if (!allowedTypes.contains(fileType.uppercase())) {
            return Localization.getString(activeLanguage, "allowed_formats_error")
        }

        val userId = loggedInUser?.id ?: 1

        viewModelScope.launch {
            // 3. Generate secure safe UUID filename
            val extension = fileType.lowercase()
            val uuidFileName = "${UUID.randomUUID()}.$extension"

            // 4. Simulate saving files in filesDir/uploads folder (Real writes simulation)
            try {
                val uploadDir = File(context.filesDir, "uploads")
                val destinationFile = File(uploadDir, uuidFileName)
                destinationFile.writeText("Student Portal uploaded file: $title (Size: $fileSizeMb MB)")
            } catch (e: Exception) {
                Log.e("MainViewModel", "File upload serialization write failed", e)
            }

            // Create Document Object
            val newDoc = Document(
                basliq = title,
                aciqlama = desc,
                faylYolu = uuidFileName,
                faylOlcusu = fileSizeMb,
                yukleyenUserId = userId,
                universitet = uni,
                ixtisas = spec,
                fənn = subject,
                downloadSayi = 0,
                upvoteSayi = 1, // Author automatic upvote
                downvoteSayi = 0,
                isApproved = true // Automatically approve for prototype plug and play
            )

            repository.insertDocument(newDoc)
            observeDocuments() // Refresh live items
        }
        return null
    }

    // SOCIAL ACTIONS (Upvote/Downvote/Comment)
    fun upvoteSelected() {
        val doc = selectedDocument ?: return
        viewModelScope.launch {
            repository.upvoteDocument(doc.id)
            selectedDocument = repository.getDocumentById(doc.id)
            observeDocuments()
        }
    }

    fun downvoteSelected() {
        val doc = selectedDocument ?: return
        viewModelScope.launch {
            repository.downvoteDocument(doc.id)
            selectedDocument = repository.getDocumentById(doc.id)
            observeDocuments()
        }
    }

    fun submitComment(text: String) {
        val doc = selectedDocument ?: return
        val user = loggedInUser ?: return
        if (text.isBlank()) return

        viewModelScope.launch {
            val newComment = Comment(
                senedId = doc.id,
                userId = user.id,
                metn = text
            )
            repository.insertComment(newComment)
            observeCommentsForSelectedDocument(doc.id)
        }
    }

    fun getAuthorName(userId: Int, onResult: (String) -> Unit) {
        viewModelScope.launch {
            val user = repository.getUserById(userId)
            if (user == null) {
                onResult(Localization.getString(activeLanguage, "anonymous_user"))
            } else if (user.isAnonymous) {
                onResult(Localization.getString(activeLanguage, "anonymous_user"))
            } else {
                onResult(user.tamAd)
            }
        }
    }

    // GEMINI CHATBOT INTERACTIONS (Modul 5)
    fun handleSendChatMessage(text: String) {
        if (text.isBlank()) return

        // 1. Add User message
        val updatedList = _chatMessages.value.toMutableList()
        updatedList.add(ChatMessage(sender = "user", text = text))
        _chatMessages.value = updatedList

        aiLoading = true

        // 2. API query with custom built system-instruction + rule fallback
        viewModelScope.launch {
            val response = GeminiClient.getAiAssistantResponse(text, activeLanguage)
            val responseList = _chatMessages.value.toMutableList()
            responseList.add(ChatMessage(sender = "ai", text = response))
            _chatMessages.value = responseList
            aiLoading = false
        }
    }

    fun resetChat() {
        _chatMessages.value = listOf(
            ChatMessage(
                sender = "ai",
                text = Localization.getString(activeLanguage, "ai_assistant_init")
            )
        )
    }
}
