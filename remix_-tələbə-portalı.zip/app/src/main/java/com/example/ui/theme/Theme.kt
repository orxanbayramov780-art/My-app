package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = MinimalBlue,
    secondary = MinimalTextLightSecondary,
    tertiary = MinimalBlueDark,
    background = MinimalBackgroundDark,
    surface = MinimalSurfaceDark,
    onPrimary = Color.White,
    onSecondary = Color.Black,
    onTertiary = Color.White,
    onBackground = MinimalTextLight,
    onSurface = MinimalTextLight,
    surfaceVariant = MinimalBorderDark,
    outlineVariant = MinimalBorderDark
)

private val LightColorScheme = lightColorScheme(
    primary = MinimalBlue,
    secondary = MinimalTextSecondary,
    tertiary = MinimalBlueDark,
    background = MinimalBackgroundLight,
    surface = Color.White,
    onPrimary = Color.White,
    onSecondary = MinimalTextDark,
    onTertiary = Color.White,
    onBackground = MinimalTextDark,
    onSurface = MinimalTextDark,
    surfaceVariant = MinimalLightGray,
    outlineVariant = MinimalBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Keep false to enforce our Clean Minimalism colors
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) {
        DarkColorScheme
    } else {
        LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
