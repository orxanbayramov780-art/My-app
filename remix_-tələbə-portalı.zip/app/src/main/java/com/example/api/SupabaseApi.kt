package com.example.api

import android.util.Log
import com.example.BuildConfig
import com.example.data.Comment
import com.example.data.Document
import com.example.data.User
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Response
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.*
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class SupabaseUserRequest(
    val tamAd: String,
    val email: String,
    val telefonNomresi: String,
    val sifreHash: String,
    val universitet: String,
    val fakulte: String,
    val ixtisas: String,
    val secilmisDil: String,
    val secilmisTema: String,
    val isAnonymous: Boolean,
    val yaradilmaTarixi: Long = System.currentTimeMillis()
)

@JsonClass(generateAdapter = true)
data class SupabaseUserResponse(
    val id: Int,
    val tamAd: String,
    val email: String,
    val telefonNomresi: String,
    val sifreHash: String,
    val universitet: String,
    val fakulte: String,
    val ixtisas: String,
    val secilmisDil: String = "AZ",
    val secilmisTema: String = "light",
    val isAnonymous: Boolean = false,
    val yaradilmaTarixi: Long
) {
    fun toRoomUser(): User = User(
        id = id,
        tamAd = tamAd,
        email = email,
        telefonNomresi = telefonNomresi,
        sifreHash = sifreHash,
        universitet = universitet,
        fakulte = fakulte,
        ixtisas = ixtisas,
        secilmisDil = secilmisDil,
        secilmisTema = secilmisTema,
        isAnonymous = isAnonymous,
        yaradilmaTarixi = yaradilmaTarixi
    )
}

@JsonClass(generateAdapter = true)
data class SupabaseDocumentRequest(
    val basliq: String,
    val aciqlama: String,
    val faylYolu: String,
    val faylOlcusu: Double,
    val yukleyenUserId: Int,
    val universitet: String,
    val ixtisas: String,
    val fənn: String,
    val downloadSayi: Int = 0,
    val upvoteSayi: Int = 0,
    val downvoteSayi: Int = 0,
    val isApproved: Boolean = true,
    val yaradilmaTarixi: Long = System.currentTimeMillis()
)

@JsonClass(generateAdapter = true)
data class SupabaseDocumentResponse(
    val id: Int,
    val basliq: String,
    val aciqlama: String,
    val faylYolu: String,
    val faylOlcusu: Double,
    val yukleyenUserId: Int,
    val universitet: String,
    val ixtisas: String,
    val fənn: String,
    val downloadSayi: Int = 0,
    val upvoteSayi: Int = 0,
    val downvoteSayi: Int = 0,
    val isApproved: Boolean = true,
    val yaradilmaTarixi: Long
) {
    fun toRoomDocument(): Document = Document(
        id = id,
        basliq = basliq,
        aciqlama = aciqlama,
        faylYolu = faylYolu,
        faylOlcusu = faylOlcusu,
        yukleyenUserId = yukleyenUserId,
        universitet = universitet,
        ixtisas = ixtisas,
        fənn = fənn,
        downloadSayi = downloadSayi,
        upvoteSayi = upvoteSayi,
        downvoteSayi = downvoteSayi,
        isApproved = isApproved,
        yaradilmaTarixi = yaradilmaTarixi
    )
}

@JsonClass(generateAdapter = true)
data class SupabaseCommentRequest(
    val senedId: Int,
    val userId: Int,
    val metn: String,
    val yaradilmaTarixi: Long = System.currentTimeMillis()
)

@JsonClass(generateAdapter = true)
data class SupabaseCommentResponse(
    val id: Int,
    val senedId: Int,
    val userId: Int,
    val metn: String,
    val yaradilmaTarixi: Long
) {
    fun toRoomComment(): Comment = Comment(
        id = id,
        senedId = senedId,
        userId = userId,
        metn = metn,
        yaradilmaTarixi = yaradilmaTarixi
    )
}

interface SupabaseApiService {
    
    // USERS TABLE
    @GET("users")
    suspend fun getUserByEmail(
        @Query("email") emailFilter: String, // format email=eq.xyz@abc.com
    ): List<SupabaseUserResponse>

    @GET("users")
    suspend fun getUserByPhone(
        @Query("telefonNomresi") phoneFilter: String, // format telefonNomresi=eq.+994...
    ): List<SupabaseUserResponse>

    @GET("users")
    suspend fun getUserById(
        @Query("id") idFilter: String, // format id=eq.1
    ): List<SupabaseUserResponse>

    @POST("users")
    @Headers("Prefer: return=representation")
    suspend fun insertUser(
        @Body user: SupabaseUserRequest
    ): List<SupabaseUserResponse>

    @PATCH("users")
    suspend fun updateUser(
        @Query("id") idFilter: String, // format id=eq.1
        @Body updates: Map<String, String>
    )

    // DOCUMENTS TABLE
    @GET("documents")
    suspend fun getAllDocuments(): List<SupabaseDocumentResponse>

    @GET("documents")
    suspend fun getDocumentsByUniversity(
        @Query("universitet") uniFilter: String // format universitet=eq.BDU
    ): List<SupabaseDocumentResponse>

    @POST("documents")
    @Headers("Prefer: return=representation")
    suspend fun insertDocument(
        @Body doc: SupabaseDocumentRequest
    ): List<SupabaseDocumentResponse>

    @PATCH("documents")
    suspend fun patchDocument(
        @Query("id") idFilter: String,
        @Body updates: Map<String, Int>
    )

    // COMMENTS TABLE
    @GET("comments")
    suspend fun getCommentsForDocument(
        @Query("senedId") docIdFilter: String // format senedId=eq.1
    ): List<SupabaseCommentResponse>

    @POST("comments")
    @Headers("Prefer: return=representation")
    suspend fun insertComment(
        @Body comment: SupabaseCommentRequest
    ): List<SupabaseCommentResponse>
}

class SupabaseAuthInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val original = chain.request()
        val apiKey = BuildConfig.SUPABASE_KEY
        
        val requestBuilder = original.newBuilder()
            .header("apikey", apiKey)
            .header("Authorization", "Bearer $apiKey")
            .header("Content-Type", "application/json")
        
        return chain.proceed(requestBuilder.build())
    }
}

object SupabaseClient {
    private const val TAG = "SupabaseClient"
    
    // In memory fallback to check integration status
    var isEnabled = true

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .addInterceptor(SupabaseAuthInterceptor())
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        })
        .build()

    val service: SupabaseApiService by lazy {
        val baseUrl = BuildConfig.SUPABASE_URL.let {
            if (it.endsWith("/")) it else "$it/"
        }
        
        val retrofit = Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create())
            .build()
        retrofit.create(SupabaseApiService::class.java)
    }

    // Helper functions for safe execution with fallback
    suspend fun <T> safeCall(fallback: T, block: suspend () -> T): T {
        if (!isEnabled) return fallback
        return try {
            block()
        } catch (e: Exception) {
            Log.e(TAG, "Supabase API call failed, using offline fallback", e)
            fallback
        }
    }
}
