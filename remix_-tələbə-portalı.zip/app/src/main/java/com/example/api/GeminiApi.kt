package com.example.api

import android.content.Context
import android.util.Log
import com.example.BuildConfig
import com.example.utils.Localization
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class Part(
    @Json(name = "text") val text: String? = null
)

@JsonClass(generateAdapter = true)
data class Content(
    @Json(name = "parts") val parts: List<Part>
)

@JsonClass(generateAdapter = true)
data class GenerateContentRequest(
    @Json(name = "contents") val contents: List<Content>,
    @Json(name = "systemInstruction") val systemInstruction: Content? = null
)

@JsonClass(generateAdapter = true)
data class Candidate(
    @Json(name = "content") val content: Content
)

@JsonClass(generateAdapter = true)
data class GenerateContentResponse(
    @Json(name = "candidates") val candidates: List<Candidate>? = null
)

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

object GeminiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    val service: GeminiApiService by lazy {
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create())
            .build()
        retrofit.create(GeminiApiService::class.java)
    }

    // High performance keyword-based bələdçi fallback (Offline response generator)
    fun getLocalAssistantResponse(query: String, lang: String): String {
        val normalized = query.lowercase().trim()
        
        return when (lang) {
            Localization.LANG_TR -> {
                when {
                    normalized.contains("dosya") || normalized.contains("yükle") || normalized.contains("belge") || normalized.contains("pdf") || normalized.contains("docx") -> {
                        "Belge Yükleme Hakkında:\n• Sağ taraftaki '+' butonuna tıklayarak yeni belgeler yükleyebilirsiniz.\n• Sistem PDF, DOCX, PNG ve JPG formatlarını destekler.\n• Güvenlik amacıyla yüklendiğinde dosya adı UUID'ye dönüştürülür.\n• Maksimum dosya boyutu sınırı **50MB**'tır."
                    }
                    normalized.contains("dil") || normalized.contains("çeviri") || normalized.contains("lisan") -> {
                        "Dil Ayarları:\n• Ayarlar sekmesinden tercih ettiğiniz dili kolayca değiştirebilirsiniz.\n• Platformumuz AZ, TR, RU ve EN olmak üzere 4 dili tam olarak desteklemektedir."
                    }
                    normalized.contains("profil") || normalized.contains("anonim") || normalized.contains("gizli") -> {
                        "Gizlilik Hakkında:\n• Ayarlar menüsünden 'Gizli Profil Durumu' özelliğini etkinleştirebilirsiniz.\n• Aktif olduğunda, paylaştığınız belgeler ve yaptığınız yorumlar diğer kullanıcılara 'Anonim Öğrenci' olarak gösterilir, gerçek isminiz asla sızmaz."
                    }
                    normalized.contains("üniversite") || normalized.contains("bdu") || normalized.contains("unec") || normalized.contains("azmiu") -> {
                        "Üniversite Bilgileri:\n• Platformumuz şu anda BDU, UNEC ve AZMİU üniversitelerini desteklemektedir.\n• Ana ekrandan üniversite seçerek sadece kendi üniversitenizin ders içeriklerini filtreleyebilirsiniz."
                    }
                    normalized.contains("sınav") || normalized.contains("ders") || normalized.contains("soru") -> {
                        "Ders ve Sınav Kaynakları:\n• Belge akışında geçmiş sınav sorularını, ders kitaplarını ve mühazirə (ders) notlarını bulabilir, indirebilir, beğenebilir ve yorum yazabilirsiniz."
                    }
                    else -> {
                        "Merhaba!\nŞu anda yerel akıllı rehber modundayım. Sınavlar, çalışma notları, anonim profil koruması veya dosya yüklemeleri hakkında sorularınızı sorabilirsiniz. Size rehberlik etmekten mutluluk duyarım!"
                    }
                }
            }
            Localization.LANG_RU -> {
                when {
                    normalized.contains("файл") || normalized.contains("загрузить") || normalized.contains("документ") || normalized.contains("pdf") || normalized.contains("docx") -> {
                        "О загрузке документов:\n• Вы можете загрузить лекции или вопросы к экзаменам, нажав кнопку '+' внизу.\n• Поддерживаются форматы PDF, DOCX, PNG и JPG.\n• Имя файла автоматически шифруется в UUID в целях безопасности.\n• Лимит размера файла составляет **50 МБ**."
                    }
                    normalized.contains("язык") || normalized.contains("перевод") -> {
                        "Языковые настройки:\n• Вы можете сменить интерфейс во вкладке Настройки.\n• Приложение поддерживает 4 языка: Азербайджанский (AZ), Турецкий (TR), Русский (RU) и Английский (EN)."
                    }
                    normalized.contains("профиль") || normalized.contains("аноним") || normalized.contains("скрыть") -> {
                        "О конфиденциальности:\n• В Настройках вы можете активировать 'Анонимный статус профиля'.\n• После этого ваше имя под загруженными файлами и комментариями будет скрыто и отображено как 'Анонимный Студент'."
                    }
                    normalized.contains("университет") || normalized.contains("бду") || normalized.contains("unec") || normalized.contains("azmiu") -> {
                        "Поддерживаемые ВУЗы:\n• На платформе представлены ведущие университеты: БГУ (BDU), UNEC и АзАСУ (AZMIU).\n• Вы можете настроить фильтр на главном экране для показа документов конкретного университета."
                    }
                    normalized.contains("экзамен") || normalized.contains("лекция") || normalized.contains("предмет") -> {
                        "Экзамены и Лекции:\n• На главной панели доступны лекционные материалы и экзаменационные вопросы, которые вы можете скачивать, оценивать и комментировать."
                    }
                    else -> {
                        "Привет!\nЯ ваш локальный умный помощник. Спросите меня о загрузке файлов, анонимности, языковых настройках или учебе в университетах Азербайджана, и я подробно отвечу!"
                    }
                }
            }
            Localization.LANG_EN -> {
                when {
                    normalized.contains("file") || normalized.contains("upload") || normalized.contains("document") || normalized.contains("pdf") || normalized.contains("docx") -> {
                        "About Uploading Documents:\n• Click the '+' FAB button to upload academic sheets, slides, or pictures.\n• Supported extensions: PDF, DOCX, PNG, and JPG.\n• Filenames are securely converted to UUID to prevent overlap.\n• Hard size limit is **50MB**."
                    }
                    normalized.contains("language") || normalized.contains("translate") || normalized.contains("lang") -> {
                        "Language Configuration:\n• Change the system language at any time in the Settings panel.\n• We support Azerbaijani (AZ), Turkish (TR), Russian (RU), and English (EN)."
                    }
                    normalized.contains("profile") || normalized.contains("anonymous") || normalized.contains("privacy") -> {
                        "User Privacy Policy:\n• Toggle 'Anonymous Status' in Settings to browse safely.\n• When selected, all your uploaded material and feedback comments will show under the pseudonym 'Anonymous Student' to keep you fully protected."
                    }
                    normalized.contains("university") || normalized.contains("bdu") || normalized.contains("unec") || normalized.contains("azmiu") -> {
                        "Higher Education Integration:\n• Built-in university coverage includes BDU, UNEC, and AZMIU.\n• Use the university filter on the home board to focus on custom materials."
                    }
                    normalized.contains("exam") || normalized.contains("lecture") || normalized.contains("study") -> {
                        "Lectures and Exam Materials:\n• Find study cards, past exam papers, and guides in the main feed tab. You can download items, upvote/downvote, and interact via comments."
                    }
                    else -> {
                        "Hello!\nI am currently running in Local Smart Guide mode. Ask me anything about files, university studies, anonymous status, or languages, and I'll assist you immediately!"
                    }
                }
            }
            else -> { // Default is LANG_AZ
                when {
                    normalized.contains("fayl") || normalized.contains("yüklə") || normalized.contains("sənəd") || normalized.contains("pdf") || normalized.contains("docx") -> {
                        "Sənəd Yüklənilməsi Haqqında:\n• Sağ aşağıdakı '+' düyməsinə klikləyərək yeni mühazirələr və ya imtahan sualları yükləyə bilərsiniz.\n• Sistem PDF, DOCX, PNG və JPG formatlarını dəstəkləyir.\n• Təhlükəsizlik məqsədilə fayl adları UUID formatına çevrilir.\n• Maksimum yükləmə limit **50MB** təşkil edir."
                    }
                    normalized.contains("dil") || normalized.contains("tərcümə") || normalized.contains("dil dəyiş") -> {
                        "Dil Tənzimləmələri:\n• Ayarlar bölməsindən platformanın dilini dərhal dəyişə bilərsiniz.\n• Tətbiqimiz AZ, TR, RU və EN dillərini tamamilə və yüksək səviyyədə dəstəkləyir."
                    }
                    normalized.contains("profil") || normalized.contains("anonim") || normalized.contains("məxfi") || normalized.contains("gizli") -> {
                        "Gizlilik və Məxfilik Memarlığı:\n• Ayarlar sekmesində 'Anonim Profil Statusu' fəaliyyətini aktiv edə bilərsiniz.\n• Aktiv olduqda, yüklədiyiniz bütün sənədlər və yazdığınız rəylər digər tələbələrə 'Anonim Tələbə' başlığı altında görünür."
                    }
                    normalized.contains("universitet") || normalized.contains("bdu") || normalized.contains("unec") || normalized.contains("azmiu") -> {
                        "Ehtiyat Universitetlərimiz:\n• Platformamıza avtomatik olaraq BDU, UNEC və AZMİU universitetləri inteqrasiya edilib.\n• Sənədlər bölməsində universitet süzgəcindən istifadə edərək yalnız öz təhsil ocağınızın sənədlərini süzə bilərsiniz."
                    }
                    normalized.contains("imtahan") || normalized.contains("dərs") || normalized.contains("sual") || normalized.contains("mühazirə") -> {
                        "Dərs və İmtahan Sualları:\n• Sənədlər lentində Azərbaycan universitetlərində keçilən dərslərin imtahan suallarını, mühazirələrini və kitablarını tapıb yükləyə, bəyənə və ya rəy yaza bilərsiniz."
                    }
                    else -> {
                        "Salam!\nHal-hazırda lokal bələdçi rejimindəyəm. Sənədlər, imtahan sualları, gizli rejim, dil tənzimləmələri və ya yükləmələr barədə istənilən sualı verə bilərsiniz, sizə ətraflı bələdçilik etməkdən şad olaram!"
                    }
                }
            }
        }
    }

    // Main API Assistant caller - guaranteed never to crash
    suspend fun getAiAssistantResponse(prompt: String, lang: String): String {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.w("GeminiClient", "API Key is empty, falling back to local guide")
            return getLocalAssistantResponse(prompt, lang)
        }

        val systemInstructionText = """
            You are a helpful AI Student Guide for the Azerbaijan Student Portal (Tələbə Portalı).
            The user's preference language is $lang.
            You must reply in $lang language.
            Respond gracefully, professionally, and clearly.
            Guide students on their lectures, exam questions, books, uploading files (within the limit of 50MB, PDF, DOCX, PNG, JPG), setting profile anonymity, and selecting 4 languages (AZ, TR, RU, EN).
            Always focus on university life and study guidance.
        """.trimIndent()

        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(text = prompt)))),
            systemInstruction = Content(parts = listOf(Part(text = systemInstructionText)))
        )

        return try {
            val response = service.generateContent(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: getLocalAssistantResponse(prompt, lang)
        } catch (e: Exception) {
            Log.e("GeminiClient", "Gemini API Request failed, invoking local fallback", e)
            getLocalAssistantResponse(prompt, lang)
        }
    }
}
