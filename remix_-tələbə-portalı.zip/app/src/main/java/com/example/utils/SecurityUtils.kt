package com.example.utils

import android.util.Base64
import java.security.MessageDigest
import org.json.JSONObject

object SecurityUtils {
    // Hashes password using SHA-256
    fun hashPassword(password: String): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val hash = digest.digest(password.toByteArray(Charsets.UTF_8))
            // Convert to Hex String
            hash.joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            password // Fallback if hashing fails (should not happen)
        }
    }

    // Compares clear text password with hashed password
    fun verifyPassword(password: String, hash: String): Boolean {
        return hashPassword(password) == hash
    }

    // Generates a mock but authentic JWT String containing user info signed with a secret key
    fun generateToken(userId: Int, email: String, tamAd: String): String {
        val header = JSONObject().apply {
            put("alg", "HS256")
            put("typ", "JWT")
        }.toString()

        val payload = JSONObject().apply {
            put("sub", userId.toString())
            put("email", email)
            put("name", tamAd)
            put("iat", System.currentTimeMillis() / 1000)
            put("exp", (System.currentTimeMillis() / 1000) + 86400) // 1 day
        }.toString()

        val base64Header = Base64.encodeToString(header.toByteArray(Charsets.UTF_8), Base64.NO_WRAP or Base64.URL_SAFE)
        val base64Payload = Base64.encodeToString(payload.toByteArray(Charsets.UTF_8), Base64.NO_WRAP or Base64.URL_SAFE)
        
        // Lightweight JWT Signature representation using static HMAC SHA256 simulation with Secret Key
        val secretKey = "v3ry_s3cr3t_f0r_azu_un1v_pl4tf0rm"
        val signatureInput = "$base64Header.$base64Payload"
        
        val digest = MessageDigest.getInstance("SHA-256")
        val signatureBytes = digest.digest((signatureInput + secretKey).toByteArray(Charsets.UTF_8))
        val base64Signature = Base64.encodeToString(signatureBytes, Base64.NO_WRAP or Base64.URL_SAFE)
            .replace("=", "")
        
        return "$base64Header.$base64Payload.$base64Signature"
    }
}
